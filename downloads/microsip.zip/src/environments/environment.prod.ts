export const environment = {
  production: true,
  apiKey: 'la api key del servidor API'
};
