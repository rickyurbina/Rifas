import { Component, OnInit } from '@angular/core';
import { MicroService } from 'src/app/services/micro.service';
import { MicroResponse, Producto } from 'src/app/interfaces';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page implements OnInit {
  
  //public productos: Producto[] = [];

  constructor( ) {}

  ngOnInit() {
    // this.microService.getTopHeadLines()
    // //.subscribe( productos  => this.productos.push(...productos));
    // // console.log(this.productos);

    // .subscribe(p=> {
    //   this.productos.push(...p);
    //   console.log(this.productos);
    // },
    // error=>{
    //   console.log(error);
    // });
  }

}
