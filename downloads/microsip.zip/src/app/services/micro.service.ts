import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { MicroResponse, Producto } from '../interfaces';
import {map} from 'rxjs/operators';
import { Observable } from 'rxjs';

const apiKey = environment.apiKey;

@Injectable({
  providedIn: 'root'
})
export class MicroService {

  constructor(private http:HttpClient) { }

  //  esta linea es para cuando necesitamos una apiKey del servidor API 
  //  con una URL 'http://192.168.1.115/apiFirebird/1.0/propiedades&apiKey=apikeydelservidorAPI'
  // getTopHeadLines(){
  //   return this.http.get('http://192.168.1.115/apiFirebird/1.0/propiedades',{
  //     params: {
  //       apiKey: apiKey
  //     }
      
  //   });


  getTopHeadLines():Observable<any>{
    //return this.http.get<MicroResponse>('http://192.168.1.115/apiFirebird/1.0/propiedades',{
      return this.http.get<MicroResponse>('https://api.loewen.com.mx/propiedades',{  

    }).pipe(
      map( resp => resp )
    );
  }
}
