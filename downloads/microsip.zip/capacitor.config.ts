import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.example.microsipApp',
  appName: 'microsip',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
